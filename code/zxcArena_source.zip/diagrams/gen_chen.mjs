// Генератор DOT-описаний инфологической модели (нотация Чена)
// для последующего рендеринга через Graphviz (kroki.io/graphviz/png).
// Атрибуты сущностей вынесены в таблицу пояснительной записки,
// на диаграмме показаны сущности, связи и кардинальности.
// Запуск: node gen_chen.mjs
import fs from "node:fs";

const entities = [
  "Зона", "Тариф", "Компьютер", "Клиент", "Сотрудник",
  "Сеанс", "Услуга", "Заказ_услуги", "Платёж", "Бронь",
];

// [связь, сущность 1, кардинальность 1, сущность 2, кардинальность 2]
const links = [
  ["Содержит",     "Зона",      "1", "Компьютер",    "N"],
  ["Действует_для","Зона",      "1", "Тариф",        "N"],
  ["Оформляет",    "Клиент",    "1", "Сеанс",        "N"],
  ["Проводит",     "Сотрудник", "1", "Сеанс",        "N"],
  ["Идёт_по",      "Тариф",     "1", "Сеанс",        "N"],
  ["Включает",     "Сеанс",     "1", "Заказ_услуги", "N"],
  ["Заказана",     "Услуга",    "1", "Заказ_услуги", "N"],
  ["Пополняет",    "Клиент",    "1", "Платёж",       "N"],
  ["Бронирует",    "Клиент",    "1", "Бронь",        "N"],
  ["Резервирует",  "Компьютер", "1", "Бронь",        "N"],
];

const out = [];
out.push("graph G {");
out.push('  graph [rankdir=TB, splines=true, nodesep=0.45, ranksep=0.85, pad=0.25, fontname="DejaVu Sans"];');
out.push('  node [fontname="DejaVu Sans", fontsize=12];');
out.push('  edge [fontname="DejaVu Sans", fontsize=11, color="#334155", penwidth=1.1];');

for (const e of entities) {
  out.push(`  "${e}" [shape=box, style="rounded,filled", fillcolor="#dbeafe", color="#1e40af", penwidth=1.3, width=1.2];`);
}

for (const [rel, e1, c1, e2, c2] of links) {
  out.push(`  "${rel}" [shape=diamond, style="filled", fillcolor="#fef3c7", color="#b45309", penwidth=1.3, width=1.1, height=0.7];`);
  out.push(`  "${e1}" -- "${rel}" [label="${c1}"];`);
  out.push(`  "${rel}" -- "${e2}" [label="${c2}"];`);
}

out.push("}");
fs.writeFileSync("er_chen.dot", out.join("\n"), "utf8");
console.log("written: er_chen.dot");
