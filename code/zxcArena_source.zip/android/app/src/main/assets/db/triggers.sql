-- ============================================================
--  Триггеры базы данных КИС «zxcArena»
--  Обеспечивают целостность данных и автоматический расчёт
--  стоимости услуг. Файл: db/triggers.sql
-- ============================================================

PRAGMA foreign_keys = ON;

-- ------------------------------------------------------------
-- 1. Запрет двух активных сеансов на одном компьютере
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_no_double
BEFORE INSERT ON sessions
WHEN NEW.status = 'active'
     AND EXISTS (SELECT 1 FROM sessions
                 WHERE computer_id = NEW.computer_id AND status = 'active')
BEGIN
    SELECT RAISE(ABORT, 'Компьютер уже занят другим сеансом');
END;

-- ------------------------------------------------------------
-- 2. Нельзя начать сеанс для заблокированного клиента
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_client_active
BEFORE INSERT ON sessions
WHEN (SELECT status FROM clients WHERE id = NEW.client_id) <> 'active'
BEGIN
    SELECT RAISE(ABORT, 'Клиент заблокирован');
END;

-- ------------------------------------------------------------
-- 3. При старте сеанса компьютер переходит в состояние «занят»
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_set_busy
AFTER INSERT ON sessions
WHEN NEW.status = 'active'
BEGIN
    UPDATE computers SET status = 'busy' WHERE id = NEW.computer_id;
END;

-- ------------------------------------------------------------
-- 4. Расчёт стоимости при завершении сеанса.
--    Тариф выбирается по времени начала: 08:00–17:59 — дневной,
--    иначе — ночной. Учитывается скидка клиента.
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_calc_cost
AFTER UPDATE OF ended_at ON sessions
WHEN NEW.ended_at IS NOT NULL AND OLD.ended_at IS NULL AND OLD.status = 'active'
BEGIN
    UPDATE sessions
       SET cost = ROUND(
               (MAX(1.0, (julianday(NEW.ended_at) - julianday(NEW.started_at)) * 1440.0) / 60.0)
               * CASE WHEN CAST(strftime('%H', NEW.started_at) AS INTEGER) BETWEEN 8 AND 17
                      THEN (SELECT day_price   FROM tariffs WHERE id = NEW.tariff_id)
                      ELSE (SELECT night_price FROM tariffs WHERE id = NEW.tariff_id)
                 END
               * (1.0 - (SELECT discount FROM clients WHERE id = NEW.client_id) / 100.0),
           2),
           status = 'closed'
     WHERE id = NEW.id;
END;

-- ------------------------------------------------------------
-- 5. Проверка достаточности средств перед закрытием сеанса
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_check_balance
BEFORE UPDATE OF ended_at ON sessions
WHEN NEW.ended_at IS NOT NULL AND OLD.ended_at IS NULL AND OLD.status = 'active'
     AND (SELECT balance FROM clients WHERE id = NEW.client_id) <
         ROUND(
             (MAX(1.0, (julianday(NEW.ended_at) - julianday(NEW.started_at)) * 1440.0) / 60.0)
             * CASE WHEN CAST(strftime('%H', NEW.started_at) AS INTEGER) BETWEEN 8 AND 17
                    THEN (SELECT day_price   FROM tariffs WHERE id = NEW.tariff_id)
                    ELSE (SELECT night_price FROM tariffs WHERE id = NEW.tariff_id)
               END
             * (1.0 - (SELECT discount FROM clients WHERE id = NEW.client_id) / 100.0),
         2)
BEGIN
    SELECT RAISE(ABORT, 'Недостаточно средств на балансе клиента');
END;

-- ------------------------------------------------------------
-- 6. Списание стоимости сеанса с баланса и освобождение ПК
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_charge_balance
AFTER UPDATE OF status ON sessions
WHEN NEW.status = 'closed' AND OLD.status = 'active'
BEGIN
    UPDATE clients
       SET balance = ROUND(balance - NEW.cost, 2)
     WHERE id = NEW.client_id;

    UPDATE computers
       SET status = 'free'
     WHERE id = NEW.computer_id;
END;

-- ------------------------------------------------------------
-- 7. Отмена сеанса освобождает компьютер
-- ------------------------------------------------------------
CREATE TRIGGER trg_sessions_cancel
AFTER UPDATE OF status ON sessions
WHEN NEW.status = 'cancelled' AND OLD.status = 'active'
BEGIN
    UPDATE computers SET status = 'free' WHERE id = NEW.computer_id;
END;

-- ------------------------------------------------------------
-- 8. Пополнение баланса и возврат средств по платежу
-- ------------------------------------------------------------
CREATE TRIGGER trg_payments_balance
AFTER INSERT ON payments
BEGIN
    UPDATE clients
       SET balance = ROUND(balance +
                    CASE NEW.type WHEN 'refund' THEN -NEW.amount ELSE NEW.amount END, 2)
     WHERE id = NEW.client_id;
END;

-- ------------------------------------------------------------
-- 9. Проверка остатка услуги перед продажей
-- ------------------------------------------------------------
CREATE TRIGGER trg_orders_stock_check
BEFORE INSERT ON service_orders
WHEN (SELECT stock FROM services WHERE id = NEW.service_id) < NEW.qty
BEGIN
    SELECT RAISE(ABORT, 'Недостаточно товара на складе');
END;

-- ------------------------------------------------------------
-- 10. Проверка достаточности средств перед продажей услуги
-- ------------------------------------------------------------
CREATE TRIGGER trg_orders_balance_check
BEFORE INSERT ON service_orders
WHEN (SELECT balance FROM clients
      WHERE id = (SELECT client_id FROM sessions WHERE id = NEW.session_id))
     < NEW.price * NEW.qty
BEGIN
    SELECT RAISE(ABORT, 'Недостаточно средств для оплаты услуги');
END;

-- ------------------------------------------------------------
-- 11. Списание остатка услуги и оплата с баланса
-- ------------------------------------------------------------
CREATE TRIGGER trg_orders_apply
AFTER INSERT ON service_orders
BEGIN
    UPDATE services
       SET stock = stock - NEW.qty
     WHERE id = NEW.service_id;

    UPDATE clients
       SET balance = ROUND(balance - NEW.price * NEW.qty, 2)
     WHERE id = (SELECT client_id FROM sessions WHERE id = NEW.session_id);
END;

-- ------------------------------------------------------------
-- 12. Запрет пересечения активных броней на одном компьютере
-- ------------------------------------------------------------
CREATE TRIGGER trg_reservations_no_overlap
BEFORE INSERT ON reservations
WHEN NEW.status = 'active'
     AND EXISTS (SELECT 1 FROM reservations r
                 WHERE r.computer_id = NEW.computer_id
                   AND r.status = 'active'
                   AND NEW.start_time < r.end_time
                   AND NEW.end_time > r.start_time)
BEGIN
    SELECT RAISE(ABORT, 'Время бронирования пересекается с существующей бронью');
END;
