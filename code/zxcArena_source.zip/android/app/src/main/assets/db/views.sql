-- ============================================================
--  Представления базы данных КИС «zxcArena»
--  Файл: db/views.sql
-- ============================================================

PRAGMA foreign_keys = ON;

-- ------------------------------------------------------------
-- 1. Активные сеансы с текущей стоимостью
-- ------------------------------------------------------------
CREATE VIEW v_active_sessions AS
SELECT s.id,
       s.client_id,
       cl.full_name                              AS client_name,
       cl.phone,
       s.computer_id,
       cmp.code                                  AS computer_code,
       z.name                                    AS zone_name,
       s.started_at,
       CAST((julianday('now', 'localtime') - julianday(s.started_at)) * 1440 AS INTEGER)
                                                 AS elapsed_minutes,
       ROUND((julianday('now', 'localtime') - julianday(s.started_at)) * 24
             * CASE WHEN CAST(strftime('%H', s.started_at) AS INTEGER) BETWEEN 8 AND 17
                    THEN t.day_price ELSE t.night_price END
             * (1.0 - cl.discount / 100.0), 2)   AS current_cost
  FROM sessions s
       JOIN clients   cl  ON cl.id  = s.client_id
       JOIN computers cmp ON cmp.id = s.computer_id
       JOIN zones     z   ON z.id   = cmp.zone_id
       JOIN tariffs   t   ON t.id   = s.tariff_id
 WHERE s.status = 'active';

-- ------------------------------------------------------------
-- 2. Состояние всех рабочих мест
-- ------------------------------------------------------------
CREATE VIEW v_computers_status AS
SELECT cmp.id,
       cmp.code,
       z.name AS zone_name,
       cmp.cpu,
       cmp.gpu,
       cmp.monitor,
       cmp.status,
       cmp.is_active,
       (SELECT cl.full_name
          FROM sessions s
               JOIN clients cl ON cl.id = s.client_id
         WHERE s.computer_id = cmp.id AND s.status = 'active'
         LIMIT 1) AS current_client
  FROM computers cmp
       JOIN zones z ON z.id = cmp.zone_id
 ORDER BY z.sort_order, cmp.code;

-- ------------------------------------------------------------
-- 3. Выручка по дням (сеансы + услуги бара)
-- ------------------------------------------------------------
CREATE VIEW v_daily_revenue AS
SELECT day,
       ROUND(SUM(amount), 2) AS revenue
  FROM (SELECT date(ended_at)      AS day, cost             AS amount
          FROM sessions
         WHERE status = 'closed'
        UNION ALL
        SELECT date(ordered_at)    AS day, price * qty      AS amount
          FROM service_orders)
 GROUP BY day
 ORDER BY day;

-- ------------------------------------------------------------
-- 4. Статистика по клиентам
-- ------------------------------------------------------------
CREATE VIEW v_client_stats AS
SELECT cl.id,
       cl.full_name,
       cl.phone,
       cl.balance,
       cl.discount,
       COUNT(s.id)                                                   AS visits,
       ROUND(COALESCE(SUM(s.cost), 0), 2)                            AS total_spent,
       ROUND(COALESCE(AVG((julianday(s.ended_at) - julianday(s.started_at)) * 1440), 0), 0)
                                                                     AS avg_minutes
  FROM clients cl
       LEFT JOIN sessions s ON s.client_id = cl.id AND s.status = 'closed'
 GROUP BY cl.id;

-- ------------------------------------------------------------
-- 5. Продажи услуг
-- ------------------------------------------------------------
CREATE VIEW v_service_sales AS
SELECT sv.id,
       sv.name,
       sv.category,
       sv.price,
       sv.stock,
       COALESCE(SUM(o.qty), 0)               AS sold_qty,
       ROUND(COALESCE(SUM(o.price * o.qty), 0), 2) AS revenue
  FROM services sv
       LEFT JOIN service_orders o ON o.service_id = sv.id
 GROUP BY sv.id;

-- ------------------------------------------------------------
-- 6. Загрузка зон
-- ------------------------------------------------------------
CREATE VIEW v_zone_load AS
SELECT z.id,
       z.name,
       COUNT(cmp.id) AS computers_total,
       SUM(CASE WHEN cmp.status = 'busy'       THEN 1 ELSE 0 END) AS busy,
       SUM(CASE WHEN cmp.status = 'free'       THEN 1 ELSE 0 END) AS free,
       SUM(CASE WHEN cmp.status = 'reserved'   THEN 1 ELSE 0 END) AS reserved,
       SUM(CASE WHEN cmp.status = 'maintenance' THEN 1 ELSE 0 END) AS maintenance
  FROM zones z
       LEFT JOIN computers cmp ON cmp.zone_id = z.id
 GROUP BY z.id;
