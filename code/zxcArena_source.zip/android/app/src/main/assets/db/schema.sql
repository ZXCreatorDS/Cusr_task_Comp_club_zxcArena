-- ============================================================
--  КИС «Компьютерный клуб zxcArena»
--  Скрипт создания реляционной базы данных (SQLite 3)
--  Файл: db/schema.sql
-- ============================================================

PRAGMA foreign_keys = ON;
PRAGMA encoding = 'UTF-8';

-- ------------------------------------------------------------
-- 1. Зоны клуба
-- ------------------------------------------------------------
CREATE TABLE zones (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL UNIQUE,
    description TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0
);

-- ------------------------------------------------------------
-- 2. Тарифы (дневной / ночной) по зонам
-- ------------------------------------------------------------
CREATE TABLE tariffs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    zone_id     INTEGER NOT NULL REFERENCES zones (id) ON DELETE RESTRICT,
    name        TEXT    NOT NULL,
    day_price   REAL    NOT NULL CHECK (day_price >= 0),
    night_price REAL    NOT NULL CHECK (night_price >= 0),
    min_minutes INTEGER NOT NULL DEFAULT 30 CHECK (min_minutes > 0),
    valid_from  TEXT    NOT NULL DEFAULT (date('now')),
    is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- ------------------------------------------------------------
-- 3. Рабочие места (компьютеры и консоли)
-- ------------------------------------------------------------
CREATE TABLE computers (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    zone_id  INTEGER NOT NULL REFERENCES zones (id) ON DELETE RESTRICT,
    code     TEXT    NOT NULL UNIQUE,
    cpu      TEXT,
    gpu      TEXT,
    monitor  TEXT,
    status   TEXT    NOT NULL DEFAULT 'free'
             CHECK (status IN ('free', 'busy', 'reserved', 'maintenance')),
    is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- ------------------------------------------------------------
-- 4. Клиенты клуба
-- ------------------------------------------------------------
CREATE TABLE clients (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT    NOT NULL,
    phone         TEXT    NOT NULL UNIQUE,
    email         TEXT,
    balance       REAL    NOT NULL DEFAULT 0 CHECK (balance >= 0),
    discount      INTEGER NOT NULL DEFAULT 0 CHECK (discount BETWEEN 0 AND 100),
    registered_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    status        TEXT    NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active', 'blocked')),
    note          TEXT
);

-- ------------------------------------------------------------
-- 5. Сотрудники
-- ------------------------------------------------------------
CREATE TABLE employees (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT    NOT NULL,
    phone         TEXT,
    role          TEXT    NOT NULL CHECK (role IN ('admin', 'manager', 'technician')),
    login         TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    hired_at      TEXT    NOT NULL,
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- ------------------------------------------------------------
-- 6. Сеансы (игровое время)
-- ------------------------------------------------------------
CREATE TABLE sessions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id      INTEGER NOT NULL REFERENCES clients (id) ON DELETE RESTRICT,
    computer_id    INTEGER NOT NULL REFERENCES computers (id) ON DELETE RESTRICT,
    employee_id    INTEGER NOT NULL REFERENCES employees (id) ON DELETE RESTRICT,
    tariff_id      INTEGER NOT NULL REFERENCES tariffs (id) ON DELETE RESTRICT,
    started_at     TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    ended_at       TEXT,
    planned_minutes INTEGER CHECK (planned_minutes IS NULL OR planned_minutes > 0),
    cost           REAL    NOT NULL DEFAULT 0 CHECK (cost >= 0),
    status         TEXT    NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active', 'closed', 'cancelled')),
    created_at     TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- ------------------------------------------------------------
-- 7. Услуги бара и дополнительный сервис
-- ------------------------------------------------------------
CREATE TABLE services (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL UNIQUE,
    category   TEXT    NOT NULL CHECK (category IN ('drink', 'food', 'rental', 'other')),
    price      REAL    NOT NULL CHECK (price >= 0),
    stock      INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    is_active  INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

-- ------------------------------------------------------------
-- 8. Заказы услуг в рамках сеанса
-- ------------------------------------------------------------
CREATE TABLE service_orders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id  INTEGER NOT NULL REFERENCES sessions (id) ON DELETE CASCADE,
    service_id  INTEGER NOT NULL REFERENCES services (id) ON DELETE RESTRICT,
    qty         INTEGER NOT NULL CHECK (qty > 0),
    price       REAL    NOT NULL CHECK (price >= 0),
    ordered_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- ------------------------------------------------------------
-- 9. Платежи (пополнение баланса и возвраты)
-- ------------------------------------------------------------
CREATE TABLE payments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients (id) ON DELETE RESTRICT,
    employee_id INTEGER NOT NULL REFERENCES employees (id) ON DELETE RESTRICT,
    amount      REAL    NOT NULL CHECK (amount > 0),
    type        TEXT    NOT NULL CHECK (type IN ('top_up', 'refund')),
    comment     TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- ------------------------------------------------------------
-- 10. Бронирование рабочих мест
-- ------------------------------------------------------------
CREATE TABLE reservations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients (id) ON DELETE CASCADE,
    computer_id INTEGER NOT NULL REFERENCES computers (id) ON DELETE CASCADE,
    start_time  TEXT    NOT NULL,
    end_time    TEXT    NOT NULL,
    status      TEXT    NOT NULL DEFAULT 'active'
                CHECK (status IN ('active', 'cancelled', 'done')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    CHECK (end_time > start_time)
);

-- ------------------------------------------------------------
-- Индексы для ускорения поиска и соединений
-- ------------------------------------------------------------
CREATE INDEX idx_sessions_computer  ON sessions (computer_id, status);
CREATE INDEX idx_sessions_client    ON sessions (client_id, started_at);
CREATE INDEX idx_computers_zone     ON computers (zone_id);
CREATE INDEX idx_clients_phone      ON clients (phone);
CREATE INDEX idx_orders_session     ON service_orders (session_id);
CREATE INDEX idx_payments_client    ON payments (client_id, created_at);
CREATE INDEX idx_reservations_time  ON reservations (computer_id, start_time);
