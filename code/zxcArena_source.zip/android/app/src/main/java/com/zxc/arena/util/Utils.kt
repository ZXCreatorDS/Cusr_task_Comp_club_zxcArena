package com.zxc.arena.util

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Хеширование паролей сотрудников (SHA-256). */
fun sha256(value: String): String {
    val bytes = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}

private val sqlFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

/** Текущие дата и время в формате SQLite. */
fun sqlNow(): String = sqlFormat.format(Date())

/** Отображение даты и времени для интерфейса. */
fun formatDateTime(value: String?): String {
    if (value.isNullOrBlank()) return "—"
    return try {
        val date = sqlFormat.parse(value)
        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(date ?: Date())
    } catch (e: Exception) {
        value
    }
}

/** Количество минут между двумя отметками времени SQLite. */
fun minutesBetween(start: String, end: String): Int {
    return try {
        val s = sqlFormat.parse(start) ?: return 0
        val e = sqlFormat.parse(end) ?: return 0
        (((e.time - s.time) / 1000) / 60).toInt().coerceAtLeast(0)
    } catch (e: Exception) {
        0
    }
}

/** Минуты с начала сеанса до текущего момента. */
fun minutesSince(start: String): Int {
    return try {
        val s = sqlFormat.parse(start) ?: return 0
        (((Date().time - s.time) / 1000) / 60).toInt().coerceAtLeast(0)
    } catch (e: Exception) {
        0
    }
}

/** Формат стоимости: 1 250,00 ₽ */
fun formatMoney(value: Double): String {
    val symbols = java.text.DecimalFormatSymbols(Locale("ru"))
    symbols.groupingSeparator = ' '
    symbols.decimalSeparator = ','
    val format = java.text.DecimalFormat("#,##0.00", symbols)
    return format.format(value) + " ₽"
}
