package com.zxc.arena.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.ui.ClubViewModel
import com.zxc.arena.ui.components.SectionTitle
import com.zxc.arena.ui.components.StatCard
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppSurfaceVariant
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonCyan
import com.zxc.arena.ui.theme.NeonGreen
import com.zxc.arena.ui.theme.NeonViolet
import com.zxc.arena.util.formatMoney

@Composable
fun ReportsScreen(vm: ClubViewModel) {
    val stats = vm.dashboard
    val maxRevenue = vm.revenue.maxOfOrNull { it.revenue } ?: 1.0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Отчёты", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(
                    "Выручка",
                    formatMoney(stats?.totalRevenue ?: 0.0),
                    NeonGreen,
                    Modifier.weight(1f)
                )
                StatCard(
                    "Сеансов активно",
                    "${stats?.activeSessions ?: 0}",
                    NeonCyan,
                    Modifier.weight(1f)
                )
            }
        }

        item { SectionTitle("Выручка по дням") }
        items(vm.revenue.size) { index ->
            val day = vm.revenue[index]
            Column(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(day.day, fontSize = 12.sp, color = AppTextMuted)
                    Text(formatMoney(day.revenue), fontSize = 12.sp, color = NeonGreen)
                }
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(AppSurfaceVariant)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(fraction = (day.revenue / maxRevenue).toFloat().coerceIn(0.03f, 1f))
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(NeonViolet)
                    )
                }
            }
        }

        item { SectionTitle("Загрузка зон") }
        items(vm.zoneLoad.size) { index ->
            val zone = vm.zoneLoad[index]
            Card(
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(zone.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(
                            "Всего: ${zone.total} · свободно: ${zone.free}",
                            fontSize = 11.sp,
                            color = AppTextMuted
                        )
                    }
                    Text(
                        "занято ${zone.busy}",
                        fontSize = 12.sp,
                        color = NeonAmber
                    )
                }
            }
        }

        item { SectionTitle("Топ услуг") }
        items(vm.topServices.size) { index ->
            val service = vm.topServices[index]
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${index + 1}. ${service.name}",
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "${service.soldQty} шт · ${formatMoney(service.revenue)}",
                    fontSize = 11.sp,
                    color = AppTextMuted
                )
            }
        }
    }
}
