package com.zxc.arena.model

/** Сотрудник клуба (администратор, менеджер, техник). */
data class Employee(
    val id: Long,
    val fullName: String,
    val role: String
)

/** Рабочее место (компьютер или консоль). */
data class ComputerRow(
    val id: Long,
    val code: String,
    val zone: String,
    val status: String,
    val gpu: String?,
    val monitor: String?,
    val clientName: String?
)

/** Клиент клуба. */
data class ClientRow(
    val id: Long,
    val fullName: String,
    val phone: String,
    val balance: Double,
    val discount: Int,
    val status: String
)

/** Активный сеанс. */
data class SessionRow(
    val id: Long,
    val clientId: Long,
    val clientName: String,
    val computerCode: String,
    val zone: String,
    val startedAt: String,
    val elapsedMinutes: Int,
    val currentCost: Double,
    val plannedMinutes: Int?
)

/** Услуга бара или проката. */
data class ServiceRow(
    val id: Long,
    val name: String,
    val category: String,
    val price: Double,
    val stock: Int
)

/** Запись истории сеансов клиента. */
data class HistoryRow(
    val id: Long,
    val computer: String,
    val startedAt: String,
    val endedAt: String?,
    val minutes: Int,
    val cost: Double,
    val status: String
)

/** Бронирование рабочего места. */
data class ReservationRow(
    val id: Long,
    val clientName: String,
    val computer: String,
    val startTime: String,
    val endTime: String,
    val status: String
)

/** Выручка за день. */
data class DayRevenue(
    val day: String,
    val revenue: Double
)

/** Загрузка зоны. */
data class ZoneLoad(
    val name: String,
    val total: Int,
    val busy: Int,
    val free: Int,
    val reserved: Int,
    val maintenance: Int
)

/** Продажи услуги. */
data class ServiceSale(
    val name: String,
    val soldQty: Int,
    val revenue: Double
)

/** Сводные показатели для главного экрана. */
data class DashboardStats(
    val activeSessions: Int,
    val freeComputers: Int,
    val totalComputers: Int,
    val totalRevenue: Double,
    val clientsCount: Int
)
