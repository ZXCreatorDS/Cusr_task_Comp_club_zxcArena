package com.zxc.arena.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Создание и обновление локальной базы данных SQLite.
 *
 * Скрипты schema.sql, triggers.sql, views.sql и seed.sql хранятся в assets/db
 * и выполняются при первом запуске приложения. Такой подход позволяет
 * использовать одни и те же SQL-скрипты в пояснительной записке и в коде.
 */
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    private val appContext = context.applicationContext

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        for (file in SCRIPT_FILES) {
            val script = appContext.assets.open("db/$file")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
            for (statement in splitStatements(script)) {
                db.execSQL(statement)
            }
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Для учебного проекта достаточно пересоздать локальную БД.
        db.execSQL("DROP VIEW IF EXISTS v_zone_load")
        db.execSQL("DROP VIEW IF EXISTS v_service_sales")
        db.execSQL("DROP VIEW IF EXISTS v_client_stats")
        db.execSQL("DROP VIEW IF EXISTS v_daily_revenue")
        db.execSQL("DROP VIEW IF EXISTS v_computers_status")
        db.execSQL("DROP VIEW IF EXISTS v_active_sessions")
        for (table in TABLES) {
            db.execSQL("DROP TABLE IF EXISTS $table")
        }
        onCreate(db)
    }

    /**
     * Разбирает SQL-скрипт на отдельные инструкции.
     * Учитывает, что тело триггера содержит точку с запятой и завершается END;.
     */
    private fun splitStatements(script: String): List<String> {
        val statements = mutableListOf<String>()
        val current = StringBuilder()
        var insideTrigger = false

        for (rawLine in script.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("--") || line.startsWith("PRAGMA")) continue

            current.append(line).append('\n')
            val upper = line.uppercase()

            if (upper.startsWith("CREATE TRIGGER")) {
                insideTrigger = true
            }

            if (insideTrigger) {
                if (upper == "END;") {
                    statements += current.toString().trim().removeSuffix(";").trim()
                    current.clear()
                    insideTrigger = false
                }
            } else if (line.endsWith(";")) {
                statements += current.toString().trim().removeSuffix(";").trim()
                current.clear()
            }
        }
        if (current.isNotBlank()) {
            statements += current.toString().trim()
        }
        return statements
    }

    companion object {
        const val DB_NAME = "zxcarena.db"
        const val DB_VERSION = 1

        private val SCRIPT_FILES = listOf("schema.sql", "triggers.sql", "views.sql", "seed.sql")

        private val TABLES = listOf(
            "service_orders", "payments", "reservations", "sessions",
            "services", "computers", "tariffs", "clients", "employees", "zones"
        )
    }
}
