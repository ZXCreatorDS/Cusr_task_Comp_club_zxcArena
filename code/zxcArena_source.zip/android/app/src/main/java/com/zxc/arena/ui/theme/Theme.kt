package com.zxc.arena.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonViolet = Color(0xFF8B5CF6)
val NeonCyan = Color(0xFF22D3EE)
val NeonAmber = Color(0xFFFBBF24)
val NeonGreen = Color(0xFF34D399)
val NeonRed = Color(0xFFF87171)

val AppBackground = Color(0xFF0B1020)
val AppSurface = Color(0xFF141A2E)
val AppSurfaceVariant = Color(0xFF1E2740)
val AppOutline = Color(0xFF2C3757)
val AppText = Color(0xFFE6EAF5)
val AppTextMuted = Color(0xFF93A0BD)

private val DarkColors = darkColorScheme(
    primary = NeonViolet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3B2A6B),
    onPrimaryContainer = Color(0xFFD8CCFF),
    secondary = NeonCyan,
    onSecondary = Color(0xFF00242B),
    tertiary = NeonAmber,
    background = AppBackground,
    onBackground = AppText,
    surface = AppSurface,
    onSurface = AppText,
    surfaceVariant = AppSurfaceVariant,
    onSurfaceVariant = AppTextMuted,
    outline = AppOutline,
    error = NeonRed
)

@Composable
fun ZxcArenaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography(),
        content = content
    )
}
