package com.zxc.arena.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.model.ClientRow
import com.zxc.arena.model.ComputerRow
import com.zxc.arena.model.SessionRow
import com.zxc.arena.ui.ClubViewModel
import com.zxc.arena.ui.components.EmptyState
import com.zxc.arena.ui.components.SectionTitle
import com.zxc.arena.ui.components.StatCard
import com.zxc.arena.ui.components.statusColor
import com.zxc.arena.ui.components.statusLabel
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppSurfaceVariant
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonCyan
import com.zxc.arena.ui.theme.NeonGreen
import com.zxc.arena.ui.theme.NeonViolet
import com.zxc.arena.util.formatMoney

@Composable
fun HallScreen(
    vm: ClubViewModel,
    onOpenReservations: () -> Unit
) {
    var startFor by remember { mutableStateOf<ComputerRow?>(null) }
    var stopFor by remember { mutableStateOf<SessionRow?>(null) }

    val stats = vm.dashboard

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        "Активных сеансов",
                        "${stats?.activeSessions ?: 0}",
                        NeonCyan,
                        Modifier.weight(1f)
                    )
                    StatCard(
                        "Свободных ПК",
                        "${stats?.freeComputers ?: 0} / ${stats?.totalComputers ?: 0}",
                        NeonGreen,
                        Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        "Выручка (всего)",
                        formatMoney(stats?.totalRevenue ?: 0.0),
                        NeonAmber,
                        Modifier.weight(1f)
                    )
                    StatCard(
                        "Клиентов в базе",
                        "${stats?.clientsCount ?: 0}",
                        NeonViolet,
                        Modifier.weight(1f)
                    )
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionTitle("Карта зала")
                TextButton(onClick = onOpenReservations) {
                    Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Брони")
                }
            }
        }

        items(vm.computers) { computer ->
            val session = vm.sessions.firstOrNull { it.computerCode == computer.code }
            ComputerCard(
                computer = computer,
                onClick = {
                    when {
                        computer.status == "busy" && session != null -> stopFor = session
                        computer.status == "free" -> startFor = computer
                    }
                }
            )
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(top = 8.dp)) {
                SectionTitle("Активные сеансы")
                if (vm.sessions.isEmpty()) {
                    EmptyState("Активных сеансов нет")
                } else {
                    vm.sessions.forEach { session ->
                        ActiveSessionCard(session) { stopFor = session }
                    }
                }
            }
        }
    }

    startFor?.let { computer ->
        StartSessionDialog(
            vm = vm,
            computer = computer,
            onDismiss = { startFor = null },
            onStarted = { startFor = null }
        )
    }

    stopFor?.let { session ->
        StopSessionDialog(
            vm = vm,
            session = session,
            onDismiss = { stopFor = null },
            onStopped = { stopFor = null }
        )
    }
}

@Composable
private fun ComputerCard(computer: ComputerRow, onClick: () -> Unit) {
    val color = statusColor(computer.status)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = computer.status == "free" || computer.status == "busy", onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    computer.code,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Box(
                    Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(color)
                )
            }
            Text(computer.zone, fontSize = 10.sp, color = AppTextMuted)
            Spacer(Modifier.height(6.dp))
            Text(
                statusLabel(computer.status),
                fontSize = 11.sp,
                color = color,
                fontWeight = FontWeight.Medium
            )
            Text(
                computer.clientName ?: (computer.gpu ?: ""),
                fontSize = 10.sp,
                color = AppTextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ActiveSessionCard(session: SessionRow, onStop: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurfaceVariant),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(session.clientName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    "${session.computerCode} · ${session.zone} · ${session.elapsedMinutes} мин",
                    fontSize = 11.sp,
                    color = AppTextMuted
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    formatMoney(session.currentCost),
                    color = NeonGreen,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                TextButton(onClick = onStop) { Text("Завершить", fontSize = 12.sp) }
            }
        }
    }
}

@Composable
private fun StartSessionDialog(
    vm: ClubViewModel,
    computer: ComputerRow,
    onDismiss: () -> Unit,
    onStarted: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ClientRow?>(null) }

    LaunchedEffect(Unit) { vm.searchClients("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Начать сеанс · ${computer.code}") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        vm.searchClients(it)
                    },
                    label = { Text("Поиск клиента") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(vm.clients) { client ->
                        val enabled = client.status == "active"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = enabled) { selected = client }
                                .background(
                                    if (selected?.id == client.id) NeonViolet.copy(alpha = 0.18f)
                                    else Color.Transparent
                                )
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(client.fullName, fontSize = 13.sp)
                                Text(
                                    "${client.phone} · ${formatMoney(client.balance)}",
                                    fontSize = 11.sp,
                                    color = if (enabled) AppTextMuted else MaterialTheme.colorScheme.error
                                )
                            }
                            if (client.discount > 0) {
                                Text(
                                    "-${client.discount}%",
                                    color = NeonAmber,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected != null,
                onClick = {
                    selected?.let {
                        if (vm.startSession(it.id, computer.id)) onStarted()
                    }
                }
            ) { Text("Начать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun StopSessionDialog(
    vm: ClubViewModel,
    session: SessionRow,
    onDismiss: () -> Unit,
    onStopped: () -> Unit
) {
    val cost = remember(session.id) { vm.currentCost(session.id) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Завершить сеанс") },
        text = {
            Column {
                Text(session.clientName, fontWeight = FontWeight.SemiBold)
                Text("${session.computerCode} · ${session.zone}", color = AppTextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Длительность", color = AppTextMuted, fontSize = 13.sp)
                    Text("${session.elapsedMinutes} мин", fontSize = 13.sp)
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("К оплате", color = AppTextMuted, fontSize = 13.sp)
                    Text(formatMoney(cost), color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (vm.stopSession(session.id)) onStopped()
            }) { Text("Завершить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
