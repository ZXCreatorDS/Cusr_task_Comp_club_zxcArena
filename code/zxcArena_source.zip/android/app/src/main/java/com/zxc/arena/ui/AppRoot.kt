package com.zxc.arena.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zxc.arena.ui.screens.ClientDetailScreen
import com.zxc.arena.ui.screens.ClientsScreen
import com.zxc.arena.ui.screens.HallScreen
import com.zxc.arena.ui.screens.LoginScreen
import com.zxc.arena.ui.screens.ReportsScreen
import com.zxc.arena.ui.screens.ReservationsScreen
import com.zxc.arena.ui.screens.ServicesScreen
import com.zxc.arena.ui.screens.SettingsScreen
import com.zxc.arena.ui.theme.AppBackground
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonCyan
import com.zxc.arena.ui.theme.NeonViolet

private sealed interface Route {
    data object Main : Route
    data class ClientCard(val clientId: Long) : Route
    data object Reservations : Route
    data object Settings : Route
}

@Composable
fun AppRoot(vm: ClubViewModel = viewModel()) {
    if (vm.employee == null) {
        LoginScreen(vm) { }
        return
    }

    var route by remember { mutableStateOf<Route>(Route.Main) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = AppBackground
    ) {
        when (val current = route) {
            Route.Main -> MainShell(
                vm = vm,
                onOpenClient = { route = Route.ClientCard(it) },
                onOpenReservations = { route = Route.Reservations },
                onOpenSettings = { route = Route.Settings }
            )
            is Route.ClientCard -> ClientDetailScreen(
                vm = vm,
                clientId = current.clientId,
                onBack = { route = Route.Main }
            )
            Route.Reservations -> ReservationsScreen(
                vm = vm,
                onBack = { route = Route.Main }
            )
            Route.Settings -> SettingsScreen(
                vm = vm,
                onBack = { route = Route.Main }
            )
        }
    }
}

private data class TabItem(val title: String, val icon: ImageVector)

@Composable
private fun MainShell(
    vm: ClubViewModel,
    onOpenClient: (Long) -> Unit,
    onOpenReservations: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    val tabs = listOf(
        TabItem("Зал", Icons.Default.SportsEsports),
        TabItem("Клиенты", Icons.Default.People),
        TabItem("Услуги", Icons.Default.LocalBar),
        TabItem("Отчёты", Icons.Default.BarChart)
    )

    Scaffold(
        containerColor = AppBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AppSurface)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        "zxcArena",
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        "${vm.employee?.fullName ?: ""} · ${vm.employee?.role ?: ""}",
                        color = AppTextMuted,
                        fontSize = 11.sp
                    )
                }
                Row {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Настройки")
                    }
                    IconButton(onClick = { vm.logout() }) {
                        Icon(Icons.Default.Logout, contentDescription = "Выход")
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = AppSurface) {
                tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = {
                            tab = index
                            if (index == 1) vm.searchClients("")
                            if (index == 2) vm.refreshAll()
                        },
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = NeonViolet,
                            selectedTextColor = NeonViolet,
                            indicatorColor = NeonViolet.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (tab) {
                0 -> HallScreen(vm, onOpenReservations)
                1 -> ClientsScreen(vm, onOpenClient)
                2 -> ServicesScreen(vm)
                else -> ReportsScreen(vm)
            }
        }
    }
}
