package com.zxc.arena.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.model.ServiceRow
import com.zxc.arena.ui.ClubViewModel
import com.zxc.arena.ui.components.EmptyState
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonCyan
import com.zxc.arena.ui.theme.NeonRed
import com.zxc.arena.util.formatMoney

private fun categoryLabel(category: String): String = when (category) {
    "drink" -> "Напитки"
    "food" -> "Еда"
    "rental" -> "Прокат"
    else -> "Прочее"
}

@Composable
fun ServicesScreen(vm: ClubViewModel) {
    var selectedSessionId by remember { mutableStateOf<Long?>(null) }
    val active = vm.sessions

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Бар и услуги", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Выберите активный сеанс, затем услугу для продажи",
            fontSize = 12.sp,
            color = AppTextMuted
        )
        Spacer(Modifier.height(10.dp))

        if (active.isEmpty()) {
            EmptyState("Нет активных сеансов — сначала начните сеанс на карте зала")
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(active) { session ->
                    FilterChip(
                        selected = selectedSessionId == session.id,
                        onClick = { selectedSessionId = session.id },
                        label = {
                            Text("${session.computerCode} · ${session.clientName}", fontSize = 11.sp)
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(vm.services) { service ->
                ServiceCard(
                    service = service,
                    enabled = selectedSessionId != null && service.stock > 0,
                    onSell = {
                        selectedSessionId?.let { vm.sellService(it, service.id) }
                    }
                )
            }
        }
    }
}

@Composable
private fun ServiceCard(service: ServiceRow, enabled: Boolean, onSell: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(service.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(categoryLabel(service.category), fontSize = 11.sp, color = AppTextMuted)
                Text(
                    "Остаток: ${service.stock}",
                    fontSize = 11.sp,
                    color = if (service.stock > 3) AppTextMuted else NeonRed
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    formatMoney(service.price),
                    fontWeight = FontWeight.SemiBold,
                    color = NeonAmber,
                    fontSize = 13.sp
                )
                TextButton(onClick = onSell, enabled = enabled) {
                    Icon(
                        Icons.Default.AddShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.height(16.dp)
                    )
                    Text("  Продать", fontSize = 12.sp)
                }
            }
        }
    }
}
