package com.zxc.arena.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.ui.ClubViewModel
import com.zxc.arena.ui.components.InfoRow
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppSurfaceVariant
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonGreen
import com.zxc.arena.ui.theme.NeonRed
import com.zxc.arena.util.formatDateTime
import com.zxc.arena.util.formatMoney

@Composable
fun ClientDetailScreen(vm: ClubViewModel, clientId: Long, onBack: () -> Unit) {
    var showTopUp by remember { mutableStateOf(false) }

    LaunchedEffect(clientId) { vm.openClient(clientId) }

    val client = vm.selectedClient

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
            }
            Text("Карточка клиента", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        if (client == null) {
            Text("Клиент не найден", color = AppTextMuted)
            return@Column
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AppSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(
                1.dp,
                if (client.status == "active") NeonGreen.copy(alpha = 0.35f)
                else NeonRed.copy(alpha = 0.35f)
            )
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(client.fullName, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(client.phone, color = AppTextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                InfoRow("Баланс", formatMoney(client.balance), NeonGreen)
                InfoRow("Скидка", "${client.discount} %", NeonAmber)
                InfoRow(
                    "Статус",
                    if (client.status == "active") "Активен" else "Заблокирован",
                    if (client.status == "active") NeonGreen else NeonRed
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { showTopUp = true },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Wallet, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("  Пополнить")
            }
            OutlinedButton(
                onClick = { vm.toggleClientStatus() },
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    if (client.status == "active") Icons.Default.Block else Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Text(if (client.status == "active") "  Блок" else "  Разблок")
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("История сеансов", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))

        if (vm.history.isEmpty()) {
            Text("Сеансов пока нет", color = AppTextMuted, fontSize = 13.sp)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.history) { row ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AppSurfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "${row.computer} · ${formatDateTime(row.startedAt)}",
                                    fontSize = 12.sp
                                )
                                Text(
                                    if (row.minutes > 0) "${row.minutes} мин" else "активен",
                                    fontSize = 11.sp,
                                    color = AppTextMuted
                                )
                            }
                            Text(
                                formatMoney(row.cost),
                                color = if (row.status == "closed") NeonGreen else AppTextMuted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }

    if (showTopUp) {
        TopUpDialog(vm, onDismiss = { showTopUp = false })
    }
}

@Composable
private fun TopUpDialog(vm: ClubViewModel, onDismiss: () -> Unit) {
    var amount by remember { mutableStateOf("1000") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Пополнение баланса") },
        text = {
            Column {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Сумма, ₽") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(500, 1000, 2000).forEach { preset ->
                        OutlinedButton(onClick = { amount = preset.toString() }) {
                            Text("$preset", fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val value = amount.toDoubleOrNull() ?: 0.0
                if (vm.topUp(value)) onDismiss()
            }) { Text("Пополнить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
