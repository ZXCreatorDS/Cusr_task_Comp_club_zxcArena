package com.zxc.arena.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonCyan
import com.zxc.arena.ui.theme.NeonGreen
import com.zxc.arena.ui.theme.NeonRed
import com.zxc.arena.util.formatMoney

/** Цвет статуса рабочего места. */
fun statusColor(status: String): Color = when (status) {
    "free" -> NeonGreen
    "busy" -> NeonRed
    "reserved" -> NeonAmber
    else -> Color(0xFF6B7280)
}

/** Название статуса на русском языке. */
fun statusLabel(status: String): String = when (status) {
    "free" -> "Свободен"
    "busy" -> "Занят"
    "reserved" -> "Бронь"
    "maintenance" -> "Ремонт"
    else -> status
}

@Composable
fun StatCard(
    label: String,
    value: String,
    accent: Color = NeonCyan,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, fontSize = 12.sp, color = AppTextMuted)
            Text(
                value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(top = 6.dp, bottom = 8.dp)
    )
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = MaterialTheme.colorScheme.onSurface) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = AppTextMuted, fontSize = 13.sp)
        Text(value, color = valueColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun MoneyText(value: Double, color: Color = NeonGreen) {
    Text(formatMoney(value), color = color, fontWeight = FontWeight.SemiBold)
}

@Composable
fun StatusBadge(status: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(statusColor(status))
        )
        Text(
            statusLabel(status),
            color = statusColor(status),
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 5.dp)
        )
    }
}

@Composable
fun EmptyState(text: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = AppTextMuted)
    }
}
