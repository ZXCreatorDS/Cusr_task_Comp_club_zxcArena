package com.zxc.arena.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.model.ClientRow
import com.zxc.arena.ui.ClubViewModel
import com.zxc.arena.ui.components.EmptyState
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppSurfaceVariant
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonGreen
import com.zxc.arena.ui.theme.NeonRed
import com.zxc.arena.ui.theme.NeonViolet
import com.zxc.arena.util.formatDateTime
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ReservationsScreen(vm: ClubViewModel, onBack: () -> Unit) {
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
            }
            Text("Бронирование", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text("  Новая")
            }
        }

        if (vm.reservations.isEmpty()) {
            EmptyState("Броней пока нет")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.reservations) { row ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AppSurface),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(row.clientName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(
                                    row.computer,
                                    color = NeonViolet,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                "${formatDateTime(row.startTime)} — ${formatDateTime(row.endTime)}",
                                fontSize = 11.sp,
                                color = AppTextMuted
                            )
                            val (label, color) = when (row.status) {
                                "active" -> "активна" to NeonGreen
                                "cancelled" -> "отменена" to NeonRed
                                else -> "завершена" to AppTextMuted
                            }
                            Text(label, fontSize = 11.sp, color = color)
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddReservationDialog(vm, onDismiss = { showAdd = false })
    }
}

private fun defaultTime(hour: Int): String {
    val calendar = Calendar.getInstance()
    calendar.add(Calendar.DAY_OF_YEAR, 1)
    calendar.set(Calendar.HOUR_OF_DAY, hour)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(calendar.timeInMillis))
}

@Composable
private fun AddReservationDialog(vm: ClubViewModel, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var selectedClient by remember { mutableStateOf<ClientRow?>(null) }
    var selectedComputerId by remember { mutableStateOf<Long?>(null) }
    var start by remember { mutableStateOf(defaultTime(18)) }
    var end by remember { mutableStateOf(defaultTime(20)) }

    LaunchedEffect(Unit) { vm.searchClients("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая бронь") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it; vm.searchClients(it) },
                    label = { Text("Клиент") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.heightIn(max = 120.dp)) {
                    items(vm.clients) { client ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selectedClient = client }
                                .background(
                                    if (selectedClient?.id == client.id)
                                        NeonViolet.copy(alpha = 0.18f) else Color.Transparent
                                )
                                .padding(vertical = 6.dp, horizontal = 4.dp)
                        ) {
                            Text(client.fullName, fontSize = 12.sp)
                        }
                    }
                }

                Text("Рабочее место", fontSize = 12.sp, color = AppTextMuted)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(vm.computers.filter { it.status == "free" }) { computer ->
                        FilterChip(
                            selected = selectedComputerId == computer.id,
                            onClick = { selectedComputerId = computer.id },
                            label = { Text(computer.code, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = start,
                    onValueChange = { start = it },
                    label = { Text("Начало (ГГГГ-ММ-ДД ЧЧ:ММ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = end,
                    onValueChange = { end = it },
                    label = { Text("Окончание") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = selectedClient != null && selectedComputerId != null,
                onClick = {
                    val client = selectedClient
                    val computerId = selectedComputerId
                    if (client != null && computerId != null) {
                        if (vm.addReservation(client.id, computerId, start, end)) onDismiss()
                    }
                }
            ) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
