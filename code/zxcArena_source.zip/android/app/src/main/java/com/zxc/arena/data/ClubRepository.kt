package com.zxc.arena.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.zxc.arena.model.ClientRow
import com.zxc.arena.model.ComputerRow
import com.zxc.arena.model.DashboardStats
import com.zxc.arena.model.DayRevenue
import com.zxc.arena.model.Employee
import com.zxc.arena.model.HistoryRow
import com.zxc.arena.model.ReservationRow
import com.zxc.arena.model.ServiceRow
import com.zxc.arena.model.ServiceSale
import com.zxc.arena.model.SessionRow
import com.zxc.arena.model.ZoneLoad
import com.zxc.arena.util.minutesBetween
import com.zxc.arena.util.sha256
import org.json.JSONArray
import org.json.JSONObject

/**
 * Репозиторий предметной области: выполняет SQL-запросы и транзакции
 * над локальной базой данных SQLite.
 */
class ClubRepository(private val context: Context) {

    private val helper = DatabaseHelper(context)
    private val db: SQLiteDatabase get() = helper.writableDatabase

    // ---------------------------------------------------------
    // Авторизация
    // ---------------------------------------------------------
    fun login(login: String, password: String): Employee? {
        db.rawQuery(
            """SELECT id, full_name, role FROM employees
               WHERE login = ? AND password_hash = ? AND is_active = 1""",
            arrayOf(login.trim(), sha256(password))
        ).use { c ->
            return if (c.moveToFirst()) {
                Employee(c.getLong(0), c.getString(1), c.getString(2))
            } else null
        }
    }

    // ---------------------------------------------------------
    // Рабочие места и сеансы
    // ---------------------------------------------------------
    fun computers(): List<ComputerRow> {
        val sql = """
            SELECT c.id, c.code, z.name, c.status, c.gpu, c.monitor,
                   (SELECT cl.full_name
                      FROM sessions s JOIN clients cl ON cl.id = s.client_id
                     WHERE s.computer_id = c.id AND s.status = 'active'
                     LIMIT 1) AS client_name
              FROM computers c
                   JOIN zones z ON z.id = c.zone_id
             WHERE c.is_active = 1
             ORDER BY z.sort_order, c.code
        """
        return query(sql) { c ->
            ComputerRow(
                id = c.getLong(0),
                code = c.getString(1),
                zone = c.getString(2),
                status = c.getString(3),
                gpu = c.getStringOrNull(4),
                monitor = c.getStringOrNull(5),
                clientName = c.getStringOrNull(6)
            )
        }
    }

    fun activeSessions(): List<SessionRow> {
        val sql = """
            SELECT id, client_id, client_name, computer_code, zone_name,
                   started_at, elapsed_minutes, current_cost,
                   (SELECT planned_minutes FROM sessions s2 WHERE s2.id = v.id) AS planned
              FROM v_active_sessions v
             ORDER BY started_at
        """
        return query(sql) { c ->
            SessionRow(
                id = c.getLong(0),
                clientId = c.getLong(1),
                clientName = c.getString(2),
                computerCode = c.getString(3),
                zone = c.getString(4),
                startedAt = c.getString(5),
                elapsedMinutes = c.getInt(6),
                currentCost = c.getDouble(7),
                plannedMinutes = if (c.isNull(8)) null else c.getInt(8)
            )
        }
    }

    /**
     * Запуск сеанса в транзакции.
     * Тариф выбирается по зоне компьютера, проверки выполняют триггеры БД.
     */
    fun startSession(clientId: Long, computerId: Long, employeeId: Long): Long {
        db.beginTransaction()
        try {
            val tariffId = db.rawQuery(
                """SELECT t.id FROM tariffs t
                    WHERE t.zone_id = (SELECT zone_id FROM computers WHERE id = ?)
                      AND t.is_active = 1
                    ORDER BY t.id LIMIT 1""",
                arrayOf(computerId.toString())
            ).use { c -> if (c.moveToFirst()) c.getLong(0) else 1L }

            val values = ContentValues().apply {
                put("client_id", clientId)
                put("computer_id", computerId)
                put("employee_id", employeeId)
                put("tariff_id", tariffId)
                put("status", "active")
            }
            val id = db.insertOrThrow("sessions", null, values)
            db.setTransactionSuccessful()
            return id
        } finally {
            db.endTransaction()
        }
    }

    /**
     * Завершение сеанса: триггер БД рассчитывает стоимость,
     * списывает средства и освобождает компьютер.
     */
    fun stopSession(sessionId: Long): Double {
        db.beginTransaction()
        try {
            db.execSQL(
                """UPDATE sessions
                      SET ended_at = datetime('now', 'localtime')
                    WHERE id = ? AND status = 'active'""",
                arrayOf(sessionId)
            )
            val cost = db.rawQuery(
                "SELECT cost FROM sessions WHERE id = ?",
                arrayOf(sessionId.toString())
            ).use { c -> if (c.moveToFirst()) c.getDouble(0) else 0.0 }
            db.setTransactionSuccessful()
            return cost
        } finally {
            db.endTransaction()
        }
    }

    fun currentSessionCost(sessionId: Long): Double {
        return db.rawQuery(
            """SELECT current_cost FROM v_active_sessions WHERE id = ?""",
            arrayOf(sessionId.toString())
        ).use { c -> if (c.moveToFirst()) c.getDouble(0) else 0.0 }
    }

    // ---------------------------------------------------------
    // Клиенты
    // ---------------------------------------------------------
    fun clients(search: String = ""): List<ClientRow> {
        val term = "%${search.trim()}%"
        val sql = """
            SELECT id, full_name, phone, balance, discount, status
              FROM clients
             WHERE full_name LIKE ? OR phone LIKE ?
             ORDER BY full_name
        """
        return query(sql, arrayOf(term, term)) { c ->
            ClientRow(
                id = c.getLong(0),
                fullName = c.getString(1),
                phone = c.getString(2),
                balance = c.getDouble(3),
                discount = c.getInt(4),
                status = c.getString(5)
            )
        }
    }

    fun client(id: Long): ClientRow? {
        return query(
            "SELECT id, full_name, phone, balance, discount, status FROM clients WHERE id = ?",
            arrayOf(id.toString())
        ) { c ->
            ClientRow(
                id = c.getLong(0),
                fullName = c.getString(1),
                phone = c.getString(2),
                balance = c.getDouble(3),
                discount = c.getInt(4),
                status = c.getString(5)
            )
        }.firstOrNull()
    }

    fun clientHistory(clientId: Long): List<HistoryRow> {
        val sql = """
            SELECT s.id, c.code, s.started_at, s.ended_at, s.cost, s.status
              FROM sessions s JOIN computers c ON c.id = s.computer_id
             WHERE s.client_id = ?
             ORDER BY s.started_at DESC
             LIMIT 50
        """
        return query(sql, arrayOf(clientId.toString())) { c ->
            val started = c.getString(2)
            val ended = c.getStringOrNull(3)
            HistoryRow(
                id = c.getLong(0),
                computer = c.getString(1),
                startedAt = started,
                endedAt = ended,
                minutes = if (ended != null) minutesBetween(started, ended) else 0,
                cost = c.getDouble(4),
                status = c.getString(5)
            )
        }
    }

    fun addClient(fullName: String, phone: String, email: String, discount: Int): Long {
        val values = ContentValues().apply {
            put("full_name", fullName.trim())
            put("phone", phone.trim())
            put("email", email.trim().ifEmpty { null })
            put("discount", discount)
            put("balance", 0.0)
            put("status", "active")
        }
        return db.insertOrThrow("clients", null, values)
    }

    fun updateClientStatus(clientId: Long, status: String) {
        db.execSQL(
            "UPDATE clients SET status = ? WHERE id = ?",
            arrayOf(status, clientId)
        )
    }

    /** Пополнение баланса: платёж и изменение баланса выполняет триггер. */
    fun topUp(clientId: Long, employeeId: Long, amount: Double) {
        val values = ContentValues().apply {
            put("client_id", clientId)
            put("employee_id", employeeId)
            put("amount", amount)
            put("type", "top_up")
            put("comment", "Пополнение через мобильное приложение")
        }
        db.insertOrThrow("payments", null, values)
    }

    // ---------------------------------------------------------
    // Услуги
    // ---------------------------------------------------------
    fun services(): List<ServiceRow> {
        return query(
            "SELECT id, name, category, price, stock FROM services WHERE is_active = 1 ORDER BY category, name"
        ) { c ->
            ServiceRow(
                id = c.getLong(0),
                name = c.getString(1),
                category = c.getString(2),
                price = c.getDouble(3),
                stock = c.getInt(4)
            )
        }
    }

    /** Продажа услуги: остаток и баланс изменяются триггерами. */
    fun sellService(sessionId: Long, serviceId: Long): Double {
        db.beginTransaction()
        try {
            db.execSQL(
                """INSERT INTO service_orders (session_id, service_id, qty, price)
                   SELECT ?, ?, 1, price FROM services WHERE id = ?""",
                arrayOf(sessionId, serviceId, serviceId)
            )
            val price = db.rawQuery(
                "SELECT price FROM services WHERE id = ?",
                arrayOf(serviceId.toString())
            ).use { c -> if (c.moveToFirst()) c.getDouble(0) else 0.0 }
            db.setTransactionSuccessful()
            return price
        } finally {
            db.endTransaction()
        }
    }

    // ---------------------------------------------------------
    // Бронирование
    // ---------------------------------------------------------
    fun reservations(): List<ReservationRow> {
        val sql = """
            SELECT r.id, cl.full_name, c.code, r.start_time, r.end_time, r.status
              FROM reservations r
                   JOIN clients cl ON cl.id = r.client_id
                   JOIN computers c ON c.id = r.computer_id
             ORDER BY r.start_time
        """
        return query(sql) { c ->
            ReservationRow(
                id = c.getLong(0),
                clientName = c.getString(1),
                computer = c.getString(2),
                startTime = c.getString(3),
                endTime = c.getString(4),
                status = c.getString(5)
            )
        }
    }

    fun addReservation(clientId: Long, computerId: Long, start: String, end: String) {
        val values = ContentValues().apply {
            put("client_id", clientId)
            put("computer_id", computerId)
            put("start_time", start)
            put("end_time", end)
            put("status", "active")
        }
        db.insertOrThrow("reservations", null, values)
    }

    // ---------------------------------------------------------
    // Отчёты
    // ---------------------------------------------------------
    fun revenueByDay(): List<DayRevenue> {
        return query("SELECT day, revenue FROM v_daily_revenue ORDER BY day DESC LIMIT 14") { c ->
            DayRevenue(c.getString(0), c.getDouble(1))
        }
    }

    fun zoneLoad(): List<ZoneLoad> {
        return query("SELECT name, computers_total, busy, free, reserved, maintenance FROM v_zone_load") { c ->
            ZoneLoad(
                c.getString(0), c.getInt(1), c.getInt(2),
                c.getInt(3), c.getInt(4), c.getInt(5)
            )
        }
    }

    fun topServices(): List<ServiceSale> {
        return query(
            """SELECT name, sold_qty, revenue FROM v_service_sales
               ORDER BY revenue DESC LIMIT 6"""
        ) { c ->
            ServiceSale(c.getString(0), c.getInt(1), c.getDouble(2))
        }
    }

    fun dashboard(): DashboardStats {
        val sql = """
            SELECT (SELECT COUNT(*) FROM sessions WHERE status = 'active'),
                   (SELECT COUNT(*) FROM computers WHERE status = 'free' AND is_active = 1),
                   (SELECT COUNT(*) FROM computers WHERE is_active = 1),
                   (SELECT COALESCE(SUM(cost), 0) FROM sessions WHERE status = 'closed')
                     + (SELECT COALESCE(SUM(price * qty), 0) FROM service_orders),
                   (SELECT COUNT(*) FROM clients)
        """
        return query(sql) { c ->
            DashboardStats(
                activeSessions = c.getInt(0),
                freeComputers = c.getInt(1),
                totalComputers = c.getInt(2),
                totalRevenue = c.getDouble(3),
                clientsCount = c.getInt(4)
            )
        }.first()
    }

    // ---------------------------------------------------------
    // Экспорт и импорт данных (обмен с центральной БД)
    // ---------------------------------------------------------
    fun exportJson(): String {
        val root = JSONObject()
        root.put("exported_at", com.zxc.arena.util.sqlNow())
        root.put("club", "zxcArena")

        val clientsArray = JSONArray()
        clients().forEach { client ->
            clientsArray.put(JSONObject().apply {
                put("full_name", client.fullName)
                put("phone", client.phone)
                put("balance", client.balance)
                put("discount", client.discount)
                put("status", client.status)
            })
        }
        root.put("clients", clientsArray)

        val servicesArray = JSONArray()
        services().forEach { service ->
            servicesArray.put(JSONObject().apply {
                put("name", service.name)
                put("category", service.category)
                put("price", service.price)
                put("stock", service.stock)
            })
        }
        root.put("services", servicesArray)
        return root.toString(2)
    }

    /** Импорт клиентов и услуг: существующие записи не дублируются. */
    fun importJson(json: String): Int {
        val root = JSONObject(json)
        var imported = 0
        db.beginTransaction()
        try {
            val clientsArray = root.optJSONArray("clients") ?: JSONArray()
            for (i in 0 until clientsArray.length()) {
                val item = clientsArray.getJSONObject(i)
                val values = ContentValues().apply {
                    put("full_name", item.optString("full_name"))
                    put("phone", item.optString("phone"))
                    put("balance", item.optDouble("balance", 0.0))
                    put("discount", item.optInt("discount", 0))
                    put("status", item.optString("status", "active"))
                }
                val id = db.insertWithOnConflict(
                    "clients", null, values, SQLiteDatabase.CONFLICT_IGNORE
                )
                if (id != -1L) imported++
            }

            val servicesArray = root.optJSONArray("services") ?: JSONArray()
            for (i in 0 until servicesArray.length()) {
                val item = servicesArray.getJSONObject(i)
                val values = ContentValues().apply {
                    put("name", item.optString("name"))
                    put("category", item.optString("category", "other"))
                    put("price", item.optDouble("price", 0.0))
                    put("stock", item.optInt("stock", 0))
                }
                val id = db.insertWithOnConflict(
                    "services", null, values, SQLiteDatabase.CONFLICT_IGNORE
                )
                if (id != -1L) imported++
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return imported
    }

    fun resetDemoData() {
        helper.close()
        context.deleteDatabase(DatabaseHelper.DB_NAME)
        helper.writableDatabase
    }

    // ---------------------------------------------------------
    // Вспомогательные методы
    // ---------------------------------------------------------
    private fun <T> query(
        sql: String,
        args: Array<String>? = null,
        mapper: (Cursor) -> T
    ): List<T> {
        val result = mutableListOf<T>()
        db.rawQuery(sql, args).use { c ->
            while (c.moveToNext()) result.add(mapper(c))
        }
        return result
    }

    private fun Cursor.getStringOrNull(index: Int): String? =
        if (isNull(index)) null else getString(index)
}
