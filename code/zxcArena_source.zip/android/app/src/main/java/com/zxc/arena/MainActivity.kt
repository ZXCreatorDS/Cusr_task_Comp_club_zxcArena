package com.zxc.arena

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.zxc.arena.ui.AppRoot
import com.zxc.arena.ui.theme.ZxcArenaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ZxcArenaTheme {
                AppRoot()
            }
        }
    }
}
