package com.zxc.arena.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zxc.arena.model.ClientRow
import com.zxc.arena.ui.ClubViewModel
import com.zxc.arena.ui.components.EmptyState
import com.zxc.arena.ui.theme.AppSurface
import com.zxc.arena.ui.theme.AppTextMuted
import com.zxc.arena.ui.theme.NeonAmber
import com.zxc.arena.ui.theme.NeonGreen
import com.zxc.arena.ui.theme.NeonRed
import com.zxc.arena.util.formatMoney

@Composable
fun ClientsScreen(vm: ClubViewModel, onOpenClient: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    LaunchedEffect(query) { vm.searchClients(query) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Клиенты", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Text("  Добавить")
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Поиск по ФИО или телефону") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))

        if (vm.clients.isEmpty()) {
            EmptyState("Клиенты не найдены")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.clients) { client ->
                    ClientCard(client) { onOpenClient(client.id) }
                }
            }
        }
    }

    if (showAdd) {
        AddClientDialog(vm, onDismiss = { showAdd = false })
    }
}

@Composable
private fun ClientCard(client: ClientRow, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(client.fullName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(client.phone, fontSize = 11.sp, color = AppTextMuted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    formatMoney(client.balance),
                    color = NeonGreen,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                val (label, color) = when {
                    client.status == "blocked" -> "заблокирован" to NeonRed
                    client.discount > 0 -> "скидка ${client.discount}%" to NeonAmber
                    else -> "активен" to AppTextMuted
                }
                Text(label, fontSize = 10.sp, color = color)
            }
        }
    }
}

@Composable
private fun AddClientDialog(vm: ClubViewModel, onDismiss: () -> Unit) {
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+7 (") }
    var email by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый клиент") },
        text = {
            Column {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("ФИО") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Телефон") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("E-mail") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = discount,
                    onValueChange = { discount = it.filter { ch -> ch.isDigit() }.take(2) },
                    label = { Text("Скидка, %") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = fullName.isNotBlank() && phone.length > 5,
                onClick = {
                    if (vm.addClient(fullName, phone, email, discount.toIntOrNull() ?: 0)) {
                        onDismiss()
                    }
                }
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
