package com.zxc.arena.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.zxc.arena.data.ClubRepository
import com.zxc.arena.model.ClientRow
import com.zxc.arena.model.ComputerRow
import com.zxc.arena.model.DashboardStats
import com.zxc.arena.model.DayRevenue
import com.zxc.arena.model.Employee
import com.zxc.arena.model.HistoryRow
import com.zxc.arena.model.ReservationRow
import com.zxc.arena.model.ServiceRow
import com.zxc.arena.model.ServiceSale
import com.zxc.arena.model.SessionRow
import com.zxc.arena.model.ZoneLoad
import java.io.File

/**
 * ViewModel приложения: хранит состояние экранов и вызывает методы репозитория.
 * Все изменения данных сразу отражаются в интерфейсе благодаря Compose State.
 */
class ClubViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ClubRepository(application.applicationContext)

    var employee by mutableStateOf<Employee?>(null)
        private set

    var message by mutableStateOf<String?>(null)
        private set

    var computers by mutableStateOf<List<ComputerRow>>(emptyList())
        private set
    var sessions by mutableStateOf<List<SessionRow>>(emptyList())
        private set
    var clients by mutableStateOf<List<ClientRow>>(emptyList())
        private set
    var services by mutableStateOf<List<ServiceRow>>(emptyList())
        private set
    var reservations by mutableStateOf<List<ReservationRow>>(emptyList())
        private set
    var history by mutableStateOf<List<HistoryRow>>(emptyList())
        private set
    var selectedClient by mutableStateOf<ClientRow?>(null)
        private set
    var dashboard by mutableStateOf<DashboardStats?>(null)
        private set
    var revenue by mutableStateOf<List<DayRevenue>>(emptyList())
        private set
    var zoneLoad by mutableStateOf<List<ZoneLoad>>(emptyList())
        private set
    var topServices by mutableStateOf<List<ServiceSale>>(emptyList())
        private set

    init {
        refreshAll()
    }

    // ---------------------------------------------------------
    // Авторизация
    // ---------------------------------------------------------
    fun login(login: String, password: String): Boolean {
        if (login.isBlank() || password.isBlank()) {
            message = "Введите логин и пароль"
            return false
        }
        return try {
            val found = repository.login(login, password)
            if (found == null) {
                message = "Неверный логин или пароль"
                false
            } else {
                employee = found
                refreshAll()
                true
            }
        } catch (e: Exception) {
            message = "Ошибка авторизации: ${e.message}"
            false
        }
    }

    fun logout() {
        employee = null
    }

    // ---------------------------------------------------------
    // Обновление данных
    // ---------------------------------------------------------
    fun refreshAll() {
        try {
            computers = repository.computers()
            sessions = repository.activeSessions()
            clients = repository.clients()
            services = repository.services()
            reservations = repository.reservations()
            dashboard = repository.dashboard()
            revenue = repository.revenueByDay()
            zoneLoad = repository.zoneLoad()
            topServices = repository.topServices()
        } catch (e: Exception) {
            message = "Ошибка чтения данных: ${e.message}"
        }
    }

    fun refreshHall() {
        try {
            computers = repository.computers()
            sessions = repository.activeSessions()
            dashboard = repository.dashboard()
        } catch (e: Exception) {
            message = e.message
        }
    }

    fun searchClients(query: String) {
        clients = try {
            repository.clients(query)
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------------------------------------------------------
    // Сеансы
    // ---------------------------------------------------------
    fun startSession(clientId: Long, computerId: Long): Boolean {
        val admin = employee ?: return false
        return try {
            repository.startSession(clientId, computerId, admin.id)
            message = "Сеанс начат"
            refreshAll()
            true
        } catch (e: Exception) {
            message = friendlyError(e.message)
            false
        }
    }

    fun stopSession(sessionId: Long): Boolean {
        return try {
            val cost = repository.stopSession(sessionId)
            message = "Сеанс завершён, списано ${"%.2f".format(cost)} ₽"
            refreshAll()
            true
        } catch (e: Exception) {
            message = friendlyError(e.message)
            false
        }
    }

    fun currentCost(sessionId: Long): Double = try {
        repository.currentSessionCost(sessionId)
    } catch (e: Exception) {
        0.0
    }

    // ---------------------------------------------------------
    // Клиенты
    // ---------------------------------------------------------
    fun openClient(clientId: Long) {
        try {
            selectedClient = repository.client(clientId)
            history = repository.clientHistory(clientId)
        } catch (e: Exception) {
            message = e.message
        }
    }

    fun topUp(amount: Double): Boolean {
        val client = selectedClient ?: return false
        val admin = employee ?: return false
        if (amount <= 0) {
            message = "Сумма должна быть больше нуля"
            return false
        }
        return try {
            repository.topUp(client.id, admin.id, amount)
            openClient(client.id)
            refreshAll()
            message = "Баланс пополнен на ${"%.2f".format(amount)} ₽"
            true
        } catch (e: Exception) {
            message = friendlyError(e.message)
            false
        }
    }

    fun addClient(fullName: String, phone: String, email: String, discount: Int): Boolean {
        return try {
            repository.addClient(fullName, phone, email, discount)
            clients = repository.clients()
            message = "Клиент добавлен"
            true
        } catch (e: Exception) {
            message = friendlyError(e.message)
            false
        }
    }

    fun toggleClientStatus() {
        val client = selectedClient ?: return
        val newStatus = if (client.status == "active") "blocked" else "active"
        try {
            repository.updateClientStatus(client.id, newStatus)
            openClient(client.id)
            clients = repository.clients()
            message = if (newStatus == "active") "Клиент разблокирован" else "Клиент заблокирован"
        } catch (e: Exception) {
            message = e.message
        }
    }

    // ---------------------------------------------------------
    // Услуги
    // ---------------------------------------------------------
    fun sellService(sessionId: Long, serviceId: Long): Boolean {
        return try {
            val price = repository.sellService(sessionId, serviceId)
            services = repository.services()
            refreshAll()
            message = "Услуга продана на ${"%.2f".format(price)} ₽"
            true
        } catch (e: Exception) {
            message = friendlyError(e.message)
            false
        }
    }

    // ---------------------------------------------------------
    // Брони
    // ---------------------------------------------------------
    fun addReservation(clientId: Long, computerId: Long, start: String, end: String): Boolean {
        return try {
            repository.addReservation(clientId, computerId, start, end)
            reservations = repository.reservations()
            message = "Бронь создана"
            true
        } catch (e: Exception) {
            message = friendlyError(e.message)
            false
        }
    }

    // ---------------------------------------------------------
    // Экспорт / импорт / сброс демо-данных
    // ---------------------------------------------------------
    fun exportData(): String? {
        return try {
            val file = File(getApplication<Application>().filesDir, "zxcArena_backup.json")
            file.writeText(repository.exportJson(), Charsets.UTF_8)
            message = "Данные выгружены: ${file.name} (${file.length()} байт)"
            file.absolutePath
        } catch (e: Exception) {
            message = "Ошибка экспорта: ${e.message}"
            null
        }
    }

    fun importData(): Boolean {
        return try {
            val file = File(getApplication<Application>().filesDir, "zxcArena_backup.json")
            if (!file.exists()) {
                message = "Файл обмена не найден — сначала выполните экспорт"
                return false
            }
            val count = repository.importJson(file.readText(Charsets.UTF_8))
            refreshAll()
            message = "Импортировано записей: $count"
            true
        } catch (e: Exception) {
            message = "Ошибка импорта: ${e.message}"
            false
        }
    }

    fun resetDemoData() {
        try {
            repository.resetDemoData()
            refreshAll()
            message = "Демонстрационные данные восстановлены"
        } catch (e: Exception) {
            message = "Ошибка сброса: ${e.message}"
        }
    }

    fun clearMessage() {
        message = null
    }

    private fun friendlyError(raw: String?): String {
        val text = raw ?: "Неизвестная ошибка"
        return when {
            text.contains("Компьютер уже занят") -> "Компьютер уже занят другим сеансом"
            text.contains("Клиент заблокирован") -> "Клиент заблокирован"
            text.contains("Недостаточно средств") -> "Недостаточно средств на балансе клиента"
            text.contains("Недостаточно товара") -> "Недостаточно товара на складе"
            text.contains("UNIQUE") && text.contains("phone") -> "Клиент с таким телефоном уже существует"
            text.contains("Время бронирования") -> "Выбранное время пересекается с другой бронью"
            else -> text
        }
    }
}
