# zxcArena — КИС компьютерного клуба

Курсовой проект по дисциплине «Разработка корпоративных информационных систем».
Тема: «Разработка мобильного приложения корпоративной информационной системы „Компьютерный клуб“».

## Состав проекта

| Каталог | Содержимое |
| --- | --- |
| `android/` | Проект Android Studio: Kotlin, Jetpack Compose, SQLite |
| `db/` | SQL-скрипты: схема, триггеры, представления, тестовые данные, демонстрационные запросы |
| `diagrams/` | Исходники и PNG-изображения UML- и ER-диаграмм |
| `docs/` | Пояснительная записка (.docx), исходники текста и скрипт сборки |
| `docs/img/` | Скриншоты приложения |

## Приложение

- Язык: Kotlin, UI: Jetpack Compose (Material 3)
- СУБД: SQLite (SQLiteOpenHelper), минимальная версия Android 7.0 (API 24)
- Сборка: Android Studio Koala или новее, JDK 17

### Запуск

1. Открыть каталог `android/` в Android Studio.
2. Дождаться синхронизации Gradle и запустить конфигурацию `app` на эмуляторе или устройстве.
3. Демонстрационные учётные данные:
   - логин `admin1`, пароль `admin123` (администратор);
   - логин `manager1`, пароль `manager123` (управляющий);
   - логин `tech1`, пароль `tech123` (техник).

При первом запуске приложение создаёт базу `zxcarena.db` и выполняет скрипты из `app/src/main/assets/db/`.
Сбросить и заново заполнить базу можно на экране «Настройки».

### Сборка из командной строки

```bash
cd android
./gradlew assembleDebug
```

Готовый APK: `android/app/build/outputs/apk/debug/app-debug.apk`.

> В `gradle.properties` включён параметр `android.overridePathCheck=true`, чтобы проект собирался из каталога с кириллицей в пути. При переносе проекта в путь без кириллицы параметр можно удалить.

## База данных

- 10 связанных таблиц, 12 триггеров, 6 представлений, индексы и ограничения `CHECK`/`FOREIGN KEY`.
- Скрипты в `db/` и в `android/app/src/main/assets/db/` идентичны.
- Проверить схему и данные можно любой программой для SQLite (например, DB Browser for SQLite), выполнив по порядку:
  `schema.sql` → `triggers.sql` → `views.sql` → `seed.sql`.

## Диаграммы

- `use_case.puml`, `class_diagram.puml`, `relational.puml`, `architecture.puml`, `screen_map.puml` — PlantUML.
- `er_chen.dot` — инфологическая модель в нотации Чена (Graphviz), генератор `gen_chen.mjs`.
- Готовые PNG лежат рядом с исходниками и вставлены в пояснительную записку.

Перегенерация PNG (PlantUML):

```bash
curl -X POST -H "Content-Type: text/plain" --data-binary @diagrams/use_case.puml https://kroki.io/plantuml/png -o diagrams/use_case.png
```

Перегенерация ER-модели:

```bash
cd diagrams
node gen_chen.mjs
curl -X POST -H "Content-Type: text/plain" --data-binary @er_chen.dot https://kroki.io/graphviz/png -o er_chen.png
```

## Пояснительная записка

`docs/Пояснительная_записка.docx` — 30 страниц основного текста (без приложений), 10 рисунков, 7 таблиц и два приложения с SQL и кодом. Рядом лежит версия в PDF.

Требования к оформлению: Times New Roman 14, интервал 1,5, поля 30/20/20/20 мм, нумерация страниц внизу по центру (начинается с 2, так как титульный лист не включён), подписи рисунков и таблиц, список литературы из 20 источников.

Пересборка записки:

```bash
cd docs
node build_docx.mjs <путь-к-проекту> <путь-к-docx>
```

Для обновления оглавления откройте документ в Word и нажмите `Ctrl+A`, затем `F9` (или «Ссылки → Обновить таблицу»).
