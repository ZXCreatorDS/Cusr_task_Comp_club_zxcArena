-- ============================================================
--  Демонстрационные запросы КИС «zxcArena»
--  Файл: db/queries.sql
-- ============================================================

-- 1. Поиск клиента по фрагменту ФИО или телефона
SELECT id, full_name, phone, balance, discount, status
  FROM clients
 WHERE full_name LIKE '%' || :query || '%'
    OR phone     LIKE '%' || :query || '%'
 ORDER BY full_name;

-- 2. Свободные рабочие места в выбранной зоне
SELECT c.id, c.code, z.name AS zone, c.gpu, c.monitor
  FROM computers c
       JOIN zones z ON z.id = c.zone_id
 WHERE z.name = :zone AND c.status = 'free' AND c.is_active = 1
 ORDER BY c.code;

-- 3. Активные сеансы с текущей стоимостью
SELECT client_name, computer_code, zone_name, started_at, elapsed_minutes, current_cost
  FROM v_active_sessions
 ORDER BY started_at;

-- 4. История сеансов клиента
SELECT s.id, c.code AS computer, s.started_at, s.ended_at,
       ROUND((julianday(s.ended_at) - julianday(s.started_at)) * 1440) AS minutes,
       s.cost, s.status
  FROM sessions s
       JOIN computers c ON c.id = s.computer_id
 WHERE s.client_id = :client_id
 ORDER BY s.started_at DESC;

-- 5. Выручка за период
SELECT ROUND(SUM(revenue), 2) AS total_revenue
  FROM v_daily_revenue
 WHERE day BETWEEN :date_from AND :date_to;

-- 6. Топ-5 услуг по выручке
SELECT name, category, sold_qty, revenue
  FROM v_service_sales
 ORDER BY revenue DESC
 LIMIT 5;

-- 7. Загрузка зон клуба
SELECT name, computers_total, busy, free, reserved, maintenance
  FROM v_zone_load
 ORDER BY id;

-- 8. Клиенты с балансом ниже заданного порога
SELECT id, full_name, phone, balance, discount
  FROM clients
 WHERE balance < :threshold AND status = 'active'
 ORDER BY balance;

-- 9. Брони на указанную дату
SELECT r.id, cl.full_name AS client, c.code AS computer,
       r.start_time, r.end_time, r.status
  FROM reservations r
       JOIN clients   cl ON cl.id = r.client_id
       JOIN computers c  ON c.id  = r.computer_id
 WHERE date(r.start_time) = :res_date AND r.status = 'active'
 ORDER BY r.start_time;

-- 10. Средняя длительность и средний чек завершённого сеанса
SELECT ROUND(AVG((julianday(ended_at) - julianday(started_at)) * 1440), 1) AS avg_minutes,
       ROUND(AVG(cost), 2) AS avg_check,
       COUNT(*) AS sessions_count
  FROM sessions
 WHERE status = 'closed';
